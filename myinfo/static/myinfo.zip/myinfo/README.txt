myinfo README
