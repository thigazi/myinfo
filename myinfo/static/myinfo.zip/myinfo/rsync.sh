#!/bin/bash
rm core/*.pyc
rm libs/*.pyc
rsync -z --update --delete-before -r --exclude=.* --exclude=*.pyc --exclude=dbx.fs --exclude=dbx.fs.* -avze ssh /storage/PyProjects/bprojekte/myinfo [2a02:d40:3:14::2]:/storage/PyProjects/bprojekte/
